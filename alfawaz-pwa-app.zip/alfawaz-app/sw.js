const CACHE_NAME = 'alfawaz-v1.2';
const DATA_CACHE = 'alfawaz-data-v1';
const SHEET_URL = 'https://docs.google.com/spreadsheets/d/1sZSnqyLvoxiaz4CnkamjVBF4Ah7ZNhAuZRoBt1rOR74/gviz/tq?tqx=out:csv&gid=0';

const STATIC_ASSETS = [
  './',
  './index.html',
  './style.css',
  './app.js',
  './manifest.json',
  'https://alfawaz-pharma.pages.dev/static/logos/warehouse.png',
  'https://alfawaz-pharma.pages.dev/static/logos/warehouse.png'
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(STATIC_ASSETS))
  );
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(
        keys
          .filter((k) => k !== CACHE_NAME && k !== DATA_CACHE)
          .map((k) => caches.delete(k))
      )
    )
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  const url = event.request.url;

  // Network-first for the Google Sheet
  if (url.includes('docs.google.com') || url.includes('gviz/tq')) {
    event.respondWith(
      fetch(event.request)
        .then((res) => {
          const clone = res.clone();
          caches.open(DATA_CACHE).then((cache) => cache.put(event.request, clone));
          return res;
        })
        .catch(() => caches.match(event.request))
    );
    return;
  }

  // Cache-first for static assets
  event.respondWith(
    caches.match(event.request).then((cached) => {
      return (
        cached ||
        fetch(event.request).then((res) => {
          if (res && res.status === 200 && event.request.method === 'GET') {
            const clone = res.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(event.request, clone));
          }
          return res;
        })
      );
    })
  );
});

// Listen for messages from the app (manual update check)
self.addEventListener('message', (event) => {
  if (event.data && event.data.type === 'CHECK_UPDATE') {
    checkForUpdate().then((result) => {
      event.ports[0].postMessage(result);
    });
  }
});

async function checkForUpdate() {
  try {
    const res = await fetch(SHEET_URL + '&_=' + Date.now(), { cache: 'no-store' });
    const text = await res.text();
    const hash = await simpleHash(text);
    return { ok: true, hash, length: text.length };
  } catch (e) {
    return { ok: false, error: e.message };
  }
}

async function simpleHash(str) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(str));
  return Array.from(new Uint8Array(buf))
    .map((b) => b.toString(16).padStart(2, '0'))
    .join('')
    .slice(0, 16);
}

// Notification click
self.addEventListener('notificationclick', (event) => {
  event.notification.close();
  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if (client.url.includes(self.location.origin) && 'focus' in client) {
          return client.focus();
        }
      }
      if (clients.openWindow) {
        return clients.openWindow('./');
      }
    })
  );
});
