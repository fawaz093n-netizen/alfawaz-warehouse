const SHEET_URL = 'https://docs.google.com/spreadsheets/d/1sZSnqyLvoxiaz4CnkamjVBF4Ah7ZNhAuZRoBt1rOR74/gviz/tq?tqx=out:csv&gid=0';
const STORAGE_KEY = 'alfawaz_data_v2';
const HASH_KEY = 'alfawaz_hash_v2';
const CART_KEY = 'alfawaz_cart_v1';
const LOGO_BASE = 'https://alfawaz-pharma.pages.dev/static/logos/';

const AGENTS = [
  { key: 'دومينا', logo: 'domina.png' },
  { key: 'بركات', logo: 'barakat.png' },
  { key: 'ميديكو', logo: 'medico.png' },
  { key: 'المتحدة', logo: 'allied.png' },
  { key: 'ابن رشد', logo: 'ibnroshed.png' },
  { key: 'لاما', logo: 'lama.png' },
  { key: 'هابي كيور', logo: 'happycure.png' },
  { key: 'سيليا', logo: 'celia.png' }
];

let allDrugs = [];
let filtered = [];
let currentCompany = 'الكل';
let cart = [];

const $ = s => document.querySelector(s);
const listEl = $('#list');
const searchEl = $('#search');
const filtersEl = $('#filters');
const statusEl = $('#status');
const countEl = $('#count');
const companiesEl = $('#companies-count');
const updateBanner = $('#update-banner');
const toastEl = $('#toast');
const cartBadge = $('#cart-badge');
const cartItemsEl = $('#cart-items');
const cartTotalEl = $('#cart-total');

function showToast(msg, success = false) {
  toastEl.textContent = msg;
  toastEl.className = 'toast show' + (success ? ' success' : '');
  setTimeout(() => toastEl.classList.remove('show'), 3000);
}

function formatPrice(p) {
  if (!p && p !== 0) return '—';
  const n = Number(String(p).replace(/[^\d.]/g, ''));
  if (isNaN(n)) return p;
  return n.toLocaleString('ar-SY');
}

function parseCSV(text) {
  const lines = text.trim().split(/\r?\n/);
  if (lines.length < 2) return [];
  const headers = lines[0].split(',').map(h => h.replace(/^"|"$/g, '').trim());
  const rows = [];
  for (let i = 1; i < lines.length; i++) {
    const cols = [];
    let cur = '', inQ = false;
    for (const ch of lines[i]) {
      if (ch === '"') { inQ = !inQ; continue; }
      if (ch === ',' && !inQ) { cols.push(cur); cur = ''; continue; }
      cur += ch;
    }
    cols.push(cur);
    if (cols.length < 5) continue;
    const obj = {};
    headers.forEach((h, idx) => obj[h] = (cols[idx] || '').trim());
    if (obj.trade_name) rows.push(obj);
  }
  return rows;
}

async function hashText(str) {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(str));
  return Array.from(new Uint8Array(buf)).map(b => b.toString(16).padStart(2, '0')).join('').slice(0, 16);
}

async function loadFromCache() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch { return null; }
}

function saveToCache(data, hash) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
  localStorage.setItem(HASH_KEY, hash);
}

function loadCart() {
  try {
    cart = JSON.parse(localStorage.getItem(CART_KEY) || '[]');
  } catch { cart = []; }
  updateCartUI();
}

function saveCart() {
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
  updateCartUI();
}

function updateCartUI() {
  const count = cart.reduce((s, i) => s + i.qty, 0);
  cartBadge.textContent = count;
  cartBadge.style.display = count ? 'flex' : 'none';
  if (!cart.length) {
    cartItemsEl.innerHTML = '<div class="cart-empty">السلة فارغة</div>';
    cartTotalEl.textContent = '0';
    return;
  }
  let total = 0;
  cartItemsEl.innerHTML = cart.map((item, idx) => {
    const price = Number(String(item.price).replace(/[^\d.]/g, '')) || 0;
    total += price * item.qty;
    return `<div class="cart-item">
      <div class="cart-item-name">${escapeHtml(item.name)} × ${item.qty}</div>
      <div class="cart-item-price">${formatPrice(price * item.qty)}</div>
      <button class="cart-item-remove" data-idx="${idx}"><i class="fas fa-trash"></i></button>
    </div>`;
  }).join('');
  cartTotalEl.textContent = formatPrice(total);
}

function addToCart(drug) {
  const existing = cart.find(i => i.id === drug.id);
  if (existing) existing.qty++;
  else cart.push({ id: drug.id, name: drug.trade_name, price: drug.price_fawaz, qty: 1 });
  saveCart();
  showToast('أُضيف إلى السلة', true);
}

async function fetchFreshData() {
  statusEl.textContent = 'جاري التحديث...';
  statusEl.className = 'status-badge checking';
  const res = await fetch(SHEET_URL + '&_t=' + Date.now(), { cache: 'no-store' });
  if (!res.ok) throw new Error('فشل الاتصال');
  const text = await res.text();
  if (text.includes('unable to open') || text.includes('<!DOCTYPE')) throw new Error('الشيت غير متاح');
  const drugs = parseCSV(text);
  if (drugs.length < 10) throw new Error('بيانات غير كافية');
  const hash = await hashText(text);
  return { drugs, hash };
}

async function checkAndUpdate(force = false) {
  try {
    const cached = await loadFromCache();
    const oldHash = localStorage.getItem(HASH_KEY);
    if (cached && cached.length && !force) {
      allDrugs = cached;
      render();
    }
    const { drugs, hash } = await fetchFreshData();
    const isNew = hash !== oldHash;
    allDrugs = drugs;
    saveToCache(drugs, hash);
    render();
    statusEl.textContent = 'محدّث اليوم';
    statusEl.className = 'status-badge updated';
    if (isNew) {
      updateBanner.classList.add('show');
      showToast(`تم تحديث البروشور • ${drugs.length} صنف`, true);
      sendNotification(drugs.length);
    } else if (force) showToast('لا يوجد تحديث جديد', true);
    return isNew;
  } catch (err) {
    console.error(err);
    statusEl.textContent = 'وضع دون اتصال';
    statusEl.className = 'status-badge';
    if (!allDrugs.length) {
      const cached = await loadFromCache();
      if (cached) { allDrugs = cached; render(); showToast('تم التحميل من الذاكرة'); }
      else listEl.innerHTML = `<div class="center-msg"><i class="fas fa-wifi"></i><p>ما في بيانات محفوظة</p></div>`;
    }
    showToast(err.message || 'خطأ في التحديث');
    return false;
  }
}

async function requestNotifPermission() {
  if (!('Notification' in window)) return false;
  if (Notification.permission === 'granted') return true;
  if (Notification.permission === 'denied') return false;
  return (await Notification.requestPermission()) === 'granted';
}

function sendNotification(count) {
  if (!('Notification' in window) || Notification.permission !== 'granted') return;
  const opts = {
    body: `تم تحديث البروشور • ${count} صنف متوفر الآن`,
    icon: LOGO_BASE + 'warehouse.png',
    badge: LOGO_BASE + 'warehouse.png',
    tag: 'alfawaz-update',
    renotify: true,
    dir: 'rtl',
    lang: 'ar'
  };
  if (navigator.serviceWorker?.controller) {
    navigator.serviceWorker.ready.then(reg => reg.showNotification('مستودع الفواز', opts));
  } else new Notification('مستودع الفواز', opts);
}

function getCompanies() {
  const set = new Set(allDrugs.map(d => d.company).filter(Boolean));
  return ['الكل', ...Array.from(set).sort((a, b) => a.localeCompare(b, 'ar'))];
}

function renderFilters() {
  const companies = getCompanies();
  filtersEl.innerHTML = companies.map(c =>
    `<button class="filter-btn ${c === currentCompany ? 'active' : ''}" data-c="${c}">${c}</button>`
  ).join('');
}

function applyFilter() {
  const q = (searchEl.value || '').trim().toLowerCase();
  filtered = allDrugs.filter(d => {
    if (currentCompany !== 'الكل' && d.company !== currentCompany) return false;
    if (!q) return true;
    return (d.trade_name || '').toLowerCase().includes(q) ||
           (d.scientific_name || '').toLowerCase().includes(q) ||
           (d.company || '').toLowerCase().includes(q) ||
           (d.form || '').toLowerCase().includes(q);
  });
  renderList();
}

function renderList() {
  countEl.textContent = filtered.length.toLocaleString('ar');
  companiesEl.textContent = (getCompanies().length - 1).toLocaleString('ar');
  if (!filtered.length) {
    listEl.innerHTML = `<div class="center-msg"><i class="fas fa-search"></i><p>ما في نتائج مطابقة</p></div>`;
    return;
  }
  const toShow = filtered.slice(0, 250);
  listEl.innerHTML = toShow.map(d => {
    const bonus = d.bonus_fawaz?.trim() || '';
    const meta = [d.form, d.strength ? d.strength + (d.unit || '') : ''].filter(Boolean).join(' • ');
    return `<div class="drug-card">
      <div class="drug-top">
        <div class="drug-name">${escapeHtml(d.trade_name)}</div>
        <span class="company-tag">${escapeHtml(d.company || '—')}</span>
      </div>
      ${meta ? `<div class="drug-meta">${escapeHtml(meta)}</div>` : ''}
      <div class="drug-bottom">
        <div class="price">${formatPrice(d.price_fawaz)} <small>ل.س</small></div>
        <div class="bonus ${bonus ? '' : 'empty'}">${bonus || 'بدون بونص'}</div>
        <button class="add-btn" data-id="${d.id}" title="أضف للسلة"><i class="fas fa-plus"></i></button>
      </div>
    </div>`;
  }).join('');
  if (filtered.length > 250) {
    listEl.innerHTML += `<div class="center-msg" style="padding:16px"><p>يظهر أول 250 • استخدم البحث للتضييق</p></div>`;
  }
}

function escapeHtml(str) {
  if (!str) return '';
  return String(str).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
}

function renderAgents() {
  $('#agents-grid').innerHTML = AGENTS.map(a =>
    `<div class="agent-card">
      <img src="${LOGO_BASE}${a.logo}" alt="${a.key}" loading="lazy" onerror="this.style.display='none'">
      <span>${a.key}</span>
    </div>`
  ).join('');
}

function render() {
  renderFilters();
  applyFilter();
}

function switchPage(page) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  $(`#page-${page}`).classList.add('active');
  document.querySelector(`.nav-item[data-page="${page}"]`).classList.add('active');
  $('#bottom-bar').style.display = page === 'catalog' ? 'flex' : 'none';
}

// Events
searchEl.addEventListener('input', () => applyFilter());
filtersEl.addEventListener('click', e => {
  const btn = e.target.closest('.filter-btn');
  if (!btn) return;
  currentCompany = btn.dataset.c;
  renderFilters();
  applyFilter();
});

$('#main-nav').addEventListener('click', e => {
  const btn = e.target.closest('.nav-item');
  if (btn) switchPage(btn.dataset.page);
});

listEl.addEventListener('click', e => {
  const btn = e.target.closest('.add-btn');
  if (!btn) return;
  const drug = allDrugs.find(d => d.id === btn.dataset.id);
  if (drug) addToCart(drug);
});

$('#btn-refresh').addEventListener('click', async () => {
  $('#btn-refresh').disabled = true;
  await checkAndUpdate(true);
  $('#btn-refresh').disabled = false;
});

$('#btn-notif').addEventListener('click', async () => {
  const ok = await requestNotifPermission();
  if (ok) { showToast('تم تفعيل الإشعارات ✓', true); sendNotification(allDrugs.length || 0); }
  else showToast('الإشعارات مرفوضة أو غير مدعومة');
});

$('#btn-cart').addEventListener('click', () => {
  $('#cart-drawer').classList.add('show');
  $('#cart-backdrop').classList.add('show');
});
$('#cart-close').addEventListener('click', closeCart);
$('#cart-backdrop').addEventListener('click', closeCart);
function closeCart() {
  $('#cart-drawer').classList.remove('show');
  $('#cart-backdrop').classList.remove('show');
}

cartItemsEl.addEventListener('click', e => {
  const btn = e.target.closest('.cart-item-remove');
  if (!btn) return;
  cart.splice(+btn.dataset.idx, 1);
  saveCart();
});

$('#btn-order-wa').addEventListener('click', () => {
  if (!cart.length) { showToast('السلة فارغة'); return; }
  let msg = 'طلب من مستودع الفواز:\n\n';
  cart.forEach(i => { msg += `• ${i.name} × ${i.qty}\n`; });
  msg += `\nالمجموع التقريبي: ${cartTotalEl.textContent} ل.س`;
  window.open('https://wa.me/963995711536?text=' + encodeURIComponent(msg), '_blank');
});

async function init() {
  if ('serviceWorker' in navigator) {
    try { await navigator.serviceWorker.register('./sw.js'); } catch (e) {}
  }
  loadCart();
  renderAgents();
  await checkAndUpdate(false);
  setInterval(() => checkAndUpdate(false), 6 * 60 * 60 * 1000);
}
init();
